package com.example.ashutoshdwivedi.tasktreeapp;

import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationMenu;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
public class MainActivity extends AppCompatActivity {

    private ActionBar mActionbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mActionbar = getSupportActionBar();
        mActionbar.setTitle("Expensia");
        Fragment home= new HomeFragment();
      loadFragment(home);

        BottomNavigationView bottomNav = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener( mOnSelectedItemListener);
    }



    private BottomNavigationView.OnNavigationItemSelectedListener mOnSelectedItemListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            Fragment fragment;

            switch(menuItem.getItemId()){
                case R.id.home_nav:
                mActionbar.setTitle("Expensia");
                return true;
                case R.id.add_nav:
                    mActionbar.setTitle("Add Expenses");
                    return true;
                case R.id.search_nav:
                    mActionbar.setTitle("Search");
                    return true;
                case R.id.profile_nav:
                    mActionbar.setTitle("Profile");
                    return true;

            }
            return false;
        }

    };

    private  void loadFragment(Fragment fragment){
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout,fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

}
